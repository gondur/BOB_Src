BDG's "Battle of Britain", 
beta version 0.98.
26.6.2003

Installation:
=============

Welcome to a much improved version of Rowan's BoB.

You can install this over any previous version you have.
This package inlcudes code and artwork changes and old patches.

The most important thing during installation is to choose
the correct BoB path. It is the path that you have installed
BoB to, in other words, the path where the bob.exe is.

After install, PLEASE FIND THE DOCUMENTATION IN THE SUBDIRECTORY "DOCS" !

First time users of our patches should also have a look at the advisor, who lives in the 
directory BDGAdvisor.

Limitations:
============

o Old savegames no longer work. Sorry!

o Some people get a light blue band in the sky

o Only the english, spanish and german versions are up-to-date.
Other versions will follow when we have the volunteers.


See us at
www.bob-ma.org


The BDG team